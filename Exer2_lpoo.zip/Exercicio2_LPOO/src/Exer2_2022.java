
import javax.swing.JOptionPane;

public class Exer2_2022 {

    public static void main(String[] args) {
        int n1, n2;
        StringBuilder mensagem = new StringBuilder();
        try {
            n1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro numero: "));
            n2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo numero: "));
            int total = n1 / n2;
            mensagem.append("Resultado da divisão é ").append(total);
            JOptionPane.showMessageDialog(null, mensagem);
        } catch (ArithmeticException a) {
            mensagem.append("Pecado da matemática cometido");
            JOptionPane.showMessageDialog(null, mensagem);
        }

    }
}
